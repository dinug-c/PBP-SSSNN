<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome</title>
</head>
<body>
    <?php
echo "<h2>Selamat datang di Praktikum PWI</ h2><br />";
echo "Hari ini parktikum : \"Sintaks Dasar PHP\"";
?>
</body>
</html>