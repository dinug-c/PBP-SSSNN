function view_alert() {
    alert("Welcomee " + document.getElementById("nama").value);
}