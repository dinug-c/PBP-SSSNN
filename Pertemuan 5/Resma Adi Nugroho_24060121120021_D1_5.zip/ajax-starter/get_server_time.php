<?php 
    // TODO 1: Tuliskan response berupa waktu server saat ini
    echo date("Y-m-d H:i:s");
    ?>